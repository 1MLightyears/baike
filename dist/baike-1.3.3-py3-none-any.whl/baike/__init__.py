from __future__ import absolute_import

from .baike import Baike,getBaike

'''
百度百科bot
by 百万光年(1MLightyears@gmail.com)
https://github.com/1MLightyears/baike

搜索百度百科并返回匹配条目的简介。

具体用法请查看README.md。
'''
